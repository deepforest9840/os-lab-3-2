#include <app.h>

int umain()
{
    du_printf("Inside app.c");

    return 0;
}
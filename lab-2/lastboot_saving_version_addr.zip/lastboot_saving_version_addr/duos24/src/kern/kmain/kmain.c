
#include <sys_init.h>
#include <cm4.h>
#include <kmain.h>
#include <stdint.h>
#include <sys_usart.h>
#include <kstdio.h>
#include <sys_rtc.h>
#include <kstring.h>
#ifndef DEBUG
#define DEBUG 1
#define BOATLOADER_SIZE (0x10000U)
#endif

static void vector_setup(void)
{
    // Set the Vector Table base address
    SCB->VTOR = 0x08020000;
}


void kmain(void)
{
     vector_setup();
   
    __sys_init();

     
    kprintf("new lab from 709  DUOS24 Running\n");
    //kprintf("team members: \n 37:Md.Sakib Ur Rahman ,41:Md.Shoriful Islam Rayhan");
    
    while (1)
    {
      
    }
}

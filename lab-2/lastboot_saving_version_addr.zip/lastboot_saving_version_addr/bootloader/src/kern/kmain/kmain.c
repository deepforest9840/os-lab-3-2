#include <sys_init.h>
#include <cm4.h>
#include <kmain.h>
#include <stdint.h>
#include <sys_usart.h>
#include <kstdio.h>
#include <sys_rtc.h>
#include <kstring.h>
#include<stdint.h>
#include<stdbool.h>
#include<sys_bus_matrix.h>

//#include<libopencm3/stm32/memorymap.h>

#ifndef DEBUG
#define DEBUG 1
#define BOATLOADER_SIZE (0x10000U) //64kB

#define Main_APP_START_ADDRESS (0x08020000U) //duos 

#define VERSION_ADDR ((volatile uint32_t *)0x2000FFFC)

//flase base = FLASH(RX): ORIGIN = 0x08000000, LENGTH = 64K

#endif

static void jump_to_main(void){

        typedef void(*void_fn)(void);
       
        uint32_t *reset_vector_entry = (uint32_t *)(Main_APP_START_ADDRESS + 4U);
        uint32_t *reset_vector= (uint32_t *)(*reset_vector_entry);

        void_fn jump_fn= (void_fn)reset_vector;

        jump_fn();

}

static void vector_setup(void)
{
    
    SCB->VTOR = 0x08000000; // Bootloader start address
}

#define FLASH_KEY1  0x45670123

#define FLASH_KEY2  0xCDEF89AB

 
void flash_unlock(void){
 
    if(FLASH->CR & FLASH_CR_LOCK){
        FLASH->KEYR = FLASH_KEY1;
        FLASH->KEYR = FLASH_KEY2;
    }
}
 
 
void flash_lock(void){
    FLASH->CR |= FLASH_CR_LOCK;
}
 void erase_os_memory_in_flash() {
    /*
    Sector 4: 0x0801 0000 - 0x0801 FFFF length= 64KB
    Sector 5: 0x0802 0000 - 0x0803 FFFF length= 128KB
    Sector 6: 0x0804 0000 - 0x0805 FFFF length= 128KB
    Sector 7: 0x0806 0000 - 0x0807 FFFF length= 128KB
    */

    flash_unlock();

    for (uint8_t sector = 0x5; sector <= 0x7; sector++) {
        while (FLASH->SR & FLASH_SR_BSY);   // Wait for flash to be ready

        // Clear any previous errors
        FLASH->SR |= (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR);

        FLASH->CR |= FLASH_CR_SER;          // Enable sector erase
        FLASH->CR &= ~(0xF << 3);           // Clear the sector number bits
        FLASH->CR |= sector << 3;           // Select the sector to erase

        FLASH->CR |= FLASH_CR_STRT;         // Start the erase operation

        while (FLASH->SR & FLASH_SR_BSY);   // Wait for the operation to complete

        // Check for errors and handle them
        if (FLASH->SR & (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR)) {
            kprintf("Error erasing sector %d\n", sector);
            FLASH->SR |= (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR); // Clear error flags
            flash_lock();
            return;
        }

        FLASH->CR &= ~FLASH_CR_SER;         // Clear sector erase bit after each erase
    }

    flash_lock();  // Lock the flash after erase operation
}




















 void erase_os_memory_in_flash1() {
    /*
    Sector 4: 0x0801 0000 - 0x0801 FFFF length= 64KB
    Sector 5: 0x0802 0000 - 0x0803 FFFF length= 128KB
    Sector 6: 0x0804 0000 - 0x0805 FFFF length= 128KB
    Sector 7: 0x0806 0000 - 0x0807 FFFF length= 128KB
    */

    flash_unlock();

    for (uint8_t sector = 0x4; sector <= 0x4; sector++) {
        while (FLASH->SR & FLASH_SR_BSY);   // Wait for flash to be ready

        // Clear any previous errors
        FLASH->SR |= (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR);

        FLASH->CR |= FLASH_CR_SER;          // Enable sector erase
        FLASH->CR &= ~(0xF << 3);           // Clear the sector number bits
        FLASH->CR |= sector << 3;           // Select the sector to erase

        FLASH->CR |= FLASH_CR_STRT;         // Start the erase operation

        while (FLASH->SR & FLASH_SR_BSY);   // Wait for the operation to complete

        // Check for errors and handle them
        if (FLASH->SR & (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR)) {
            kprintf("Error erasing sector %d\n", sector);
            FLASH->SR |= (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR); // Clear error flags
            flash_lock();
            return;
        }

        FLASH->CR &= ~FLASH_CR_SER;         // Clear sector erase bit after each erase
    }

    flash_lock();  // Lock the flash after erase operation
}















// int flash_erased_check(void){
 
//     int start_address = Main_APP_START_ADDRESS;
//     int end_address = Main_APP_START_ADDRESS + 0x1000U;
 
//     for(int i=start_address; i<end_address; i+=4){
//         if(*(uint32_t*)i != 0xFFFFFFFF){

//              kprintf("flash erases checked\n");
//             return 0;
//         }
//     }
//     kprintf("flash erases checked\n");
//     return 1;
// }
 
// #define FLASH_KEY1  0x45670123
// #define FLASH_KEY2  0xCDEF89AB

// void flash_unlock(void) {
//     if (FLASH->CR & FLASH_CR_LOCK) {
//         FLASH->KEYR = FLASH_KEY1;
//         FLASH->KEYR = FLASH_KEY2;
//     }
// }

// void flash_lock(void) {
//     FLASH->CR |= FLASH_CR_LOCK;
// }

// void erase_os_memory_in_flash() {
//     flash_unlock();

//     for (uint8_t sector = 0x4; sector <= 0x7; sector++) {
//         while (FLASH->SR & FLASH_SR_BSY);  // Wait for flash to be ready

//         // Clear any previous errors
//         FLASH->SR |= (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR);

//         FLASH->CR |= FLASH_CR_SER;         // Enable sector erase
//         FLASH->CR &= ~(0xF << 3);          // Clear the sector number bits
//         FLASH->CR |= sector << 3;          // Select the sector to erase

//         FLASH->CR |= FLASH_CR_STRT;        // Start the erase operation

//         while (FLASH->SR & FLASH_SR_BSY);  // Wait for the operation to complete

//         // Check for errors and handle them
//         if (FLASH->SR & (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR)) {
//             kprintf("Error erasing sector %d\n", sector);
//             FLASH->SR |= (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR); // Clear error flags
//             flash_lock();
//             return;
//         }

//         FLASH->CR &= ~FLASH_CR_SER;        // Clear sector erase bit after each erase
//     }

//     flash_lock();  // Lock the flash after erase operation
// }
void flash_write(uint8_t* data, uint32_t length, uint32_t start_address) {
    // Unlock flash before writing
    erase_os_memory_in_flash();
    flash_unlock();

    FLASH->CR |= FLASH_CR_PG;  // Enable programming mode for flash

    for (uint32_t i = 0; i < length; i++) {
        // Write one byte at a time to flash memory
        *(uint8_t *)(start_address + i) = data[i];

        // Wait until the flash is not busy
        while (FLASH->SR & FLASH_SR_BSY);

        // Verify the written data
        if (*(uint8_t *)(start_address + i) != data[i]) {
            kprintf("Verification failed at address 0x%x\n", (start_address + i));
            flash_lock();
            return;
        }

        // Check for any errors
        if (FLASH->SR & (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR)) {
            kprintf("Error writing to flash at address 0x%x\n", (start_address + i));
            FLASH->SR |= (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR);  // Clear error flags
            flash_lock();  // Lock flash after error
            return;
        }
    }

    FLASH->CR &= ~FLASH_CR_PG;  // Disable programming mode after writing
    flash_lock();  // Lock the flash after writing
}













void flash_write1(uint8_t* data, uint32_t length, uint32_t start_address) {
    // Unlock flash before writing
   erase_os_memory_in_flash1();

    flash_unlock();

    FLASH->CR |= FLASH_CR_PG;  // Enable programming mode for flash

    for (uint32_t i = 0; i < length; i++) {
        // Write one byte at a time to flash memory
        *(uint8_t *)(start_address + i) = data[i];

        // Wait until the flash is not busy
        while (FLASH->SR & FLASH_SR_BSY);

        // Verify the written data
        if (*(uint8_t *)(start_address + i) != data[i]) {
            kprintf("Verification failed at address 0x%x\n", (start_address + i));
            flash_lock();
            return;
        }

        // Check for any errors
        if (FLASH->SR & (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR)) {
            kprintf("Error writing to flash at address 0x%x\n", (start_address + i));
            FLASH->SR |= (FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR);  // Clear error flags
            flash_lock();  // Lock flash after error
            return;
        }
    }

    FLASH->CR &= ~FLASH_CR_PG;  // Disable programming mode after writing
    flash_lock();  // Lock the flash after writing
}
















// void flash_write(uint8_t* data, uint32_t length, uint32_t start_address){
 
//     flash_unlock();
 
//     while(FLASH->SR & FLASH_SR_BSY); // Wait for the flash to be ready
 
//     FLASH->CR |= FLASH_CR_PG; // Programming enabled
 
//     for(uint32_t i=0; i<length; i+=4){
 
//         *(uint32_t*)(start_address + i) = *(uint32_t*)(data + i);
 
//         while(FLASH->SR & FLASH_SR_BSY); // Wait for the flash to be ready
//     }
 
//     FLASH->CR &= ~FLASH_CR_PG; // Programming disabled
 
  
//  flash_lock();
// }









// void flash_write(uint8_t *data, uint32_t length, uint32_t start_address) {
//     // Unlock the flash memory for writing
//     flash_unlock();

//     // Wait until flash is not busy
//     while (FLASH->SR & FLASH_SR_BSY);

//     // Enable programming mode
//     FLASH->CR |= FLASH_CR_PG;

//     // Pad length to the next multiple of 4 if needed
//     uint32_t aligned_length = (length + 3) & ~3;

//     // Write data in 32-bit words
//     for (uint32_t i = 0; i < aligned_length; i += 4) {
//         uint32_t word = (i < length) ? *(uint32_t *)(data + i) : 0xFFFFFFFF; // Pad with 0xFFFFFFFF

//         *(uint32_t *)(start_address + i) = word;

//         // Wait until flash is not busy
//         while (FLASH->SR & FLASH_SR_BSY);

//         // Check for End of Programming (EOP) and clear it
//         if (FLASH->SR & FLASH_SR_EOP) {
//             FLASH->SR |= FLASH_SR_EOP; // Clear EOP flag
//         } else {
//             // If EOP not set, there was an error
//             kprintf("Flash write error at address: 0x%08X\n", start_address + i);
//             break;
//         }
//     }

//     // Disable programming mode
//     FLASH->CR &= ~FLASH_CR_PG;

//     // Lock the flash memory to prevent further writes
//     flash_lock();
// }











// void flash_read(uint8_t* data, uint32_t length, uint32_t start_address){
 
//     for(uint32_t i=0; i<length; i+=4){
 
//         *(uint32_t*)(data + i) = *(uint32_t*)(start_address + i);
 
//         while(FLASH->SR & FLASH_SR_BSY);
 
//     }
 
// }



#include <stdint.h>

void flash_read(uint32_t length, uint32_t start_address) {
    uint8_t data[length];  // Allocate an array to store the data read from flash
    
    for (uint32_t i = 0; i < length; i++) {
        // Read one byte from flash
        data[i] = *(uint8_t *)(start_address + i);

        // Display the byte in both hexadecimal and character format
        if (data[i] >= 32 && data[i] <= 126) {  // Check if the byte is a printable ASCII character
            kprintf("Data at from flash read  0x%x: 0x%02X ('%c')\n", (start_address + i), data[i], data[i]);
        } else {
            kprintf("Data at from flash read 0x%x: 0x%02X\n", (start_address + i), data[i]);
        }

        // Wait until the flash is not busy
        while (FLASH->SR & FLASH_SR_BSY);
    }
}






/*
    CRC Calculation
*/

void crc_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_CRCEN;
}

uint32_t Calculate_checksum(uint8_t *data, uint32_t length)
{
   
    CRCR->CR = CRC_CR_RESET; // Reset the CRC calculation
    for (uint32_t i = 0; i < length; i++)
    {
        CRCR->DR = data[i]; // Feed data to the CRC calculator
    }
    return CRCR->DR; // Return the calculated CRC value
}





void USART2Config(void){
	
	// 1 Enable the UART clock
	RCC->APB1ENR |= (1<<17); // Enable UART2 clock
	
	// 2 Enable GPIOA clock for TX and RX pins
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
	
	// 3 Configure the UART pins for alternate functions
	GPIOA->MODER |= (2<<4); // Bits [5:4] = 1:0--> Alternate function for pin PA2
	GPIOA->MODER |= (2<<6); // Bits [6:7] = 1:0--> Alternate function for pin PA3
	
	GPIOA->OSPEEDR |= (3<<4) | (3<<6); //High speed for pin PA2 and PA3 
	
	GPIOA->AFR[0] |=(7<<8); // 0 for low alternate register 1 for hight alternate register
	GPIOA->AFR[0] |=(7<<12);
	
	// 3 Enable the USART 
	USART2->CR1 = 0x00;
	USART2->CR1 |= (1<<13); // Enable USART2
	
	// 4 Set the word length 
	USART2->CR1 &= ~(1U<<12); // M= 0 means 8 bit word length
	
	// 5 select the baud rate
	USART2->BRR |= (7<<0) | (24<<4); //115200 PLK1 at 45MHz
	
	
	//  6. Enable TX and RX in USART_CR1 register
	USART2->CR1 |= (1<<2); // enable RE for receiver 
	USART2->CR1 |= (1<<3); //enable TE for transmitter
}


void USART2SendChar(uint8_t c){
	// 1 Write the data to be sent in the USART2->DR
	
	USART2->DR = c; 
	while(!(USART2->SR &(1<<6))); // Wait for TC to set. This indicates that the data has been transmitter
	
	
}

void USART2SendString(char *s){
	
	
	while(*s){
		USART2SendChar(*s++);
		
	}
	
}

// uint8_t USART2GetChar(void){
	
// 	// 1 Check the status register
// 	while(!(USART2->SR & (1<<5)));
	
// 	// 2 Read the data from the data register
// 	uint8_t temp;
// 	temp = (uint8_t) USART2->DR;
	
// 	return temp;
// }




uint8_t UART_GetChar1(USART_TypeDef *usart){
	uint8_t tmp;
	while(!(usart->SR & (1<<5)));
	tmp=(uint8_t)usart->DR;
	return tmp;
}
void UART_GetString1(USART_TypeDef *uart,uint16_t size,uint8_t* buff)
{
	uint16_t i=0;
	while(size--)
	{
		uint8_t x=UART_GetChar1(uart);
		buff[i]=x;
		i++;
	}
	buff[i]='\0';
		
}




int string_to_int( char *str) {
    int result = 0;
    int i = 0;
    int sign = 1;

    // Handle negative numbers
    if (str[0] == '-') {
        sign = -1;
        i++;  // Start conversion from the next character
    }

    // Iterate over each character in the string
    while (str[i] != '\0') {
        // Convert character to integer and accumulate
        result = result * 10 + (str[i] - '0');
        i++;
    }

    return result * sign;
}


uint8_t USART2ReceiveChar(void)
{
    while (!(USART2->SR & (1 << 5)))
        ; // Wait for RXNE to set. This indicates that the data has been received
    return (uint8_t)USART2->DR;
}


uint8_t calculate_checksum(const uint8_t* data, size_t length) {
    uint8_t checksum = 0;
    for (size_t i = 0; i < length; i++) {
        checksum ^= data[i];
    }
    return checksum;
}
#define FLASH_BASE    0x08000000    // Start of the flash memory
#define FLASH_END     0x080FFFFF    // End of the flash memory (adjust depending on your device)










#define MAX_FILE_SIZE 0x8000 // Maximum file size (32KB for example), adjust as necessary
#define CHUNK_SIZE 32  // Chunk size for receiving data

// Temporary buffer to hold the entire binary file data
uint8_t file_buffer[MAX_FILE_SIZE];

// Manual memory copy function
void manual_copy(uint8_t* dest, uint8_t* src, size_t size) {
    for (size_t i = 0; i < size; i++) {
        dest[i] = src[i];
    }
}

void USART2ReceiveBinary1(uint8_t *buffer, size_t size, uint32_t start_address) {
    size_t offset = 0;
    uint8_t chunk[CHUNK_SIZE];  // Temporary buffer for each chunk
    uint8_t received_checksum;
    uint8_t calculated_checksum;

    // Step 1: Receive data in chunks and store it in the buffer
    while (offset < size) {
        size_t remaining = size - offset;
        size_t chunk_size = (remaining >= CHUNK_SIZE) ? CHUNK_SIZE : remaining;

        // Receive a chunk of data
        UART_GetString1(USART2, chunk_size, chunk);

        // Receive the checksum for this chunk
        received_checksum = UART_GetChar1(USART2);

        // Calculate checksum for the received chunk
        calculated_checksum = calculate_checksum(chunk, chunk_size);

        // Check if the checksum matches
        if (calculated_checksum == received_checksum) {
            // Copy the chunk into the file buffer
            manual_copy(file_buffer + offset, chunk, chunk_size);
            
            // Acknowledge successful reception
            kprintf("OK\n");
            offset += chunk_size;
        } else {
            // If checksum mismatch, ask for retransmission
            kprintf("RESEND\n");
        }
    }

    // Step 2: After receiving the entire file, write it to flash
    if (start_address < FLASH_BASE || start_address > FLASH_END) {
        kprintf("Invalid flash address\n");
        return;
    }

    // Write the entire file to flash
    flash_write(file_buffer, size, start_address);

    // Acknowledge successful write
    kprintf("All data received and written to flash.\n");
}


















// void flash_read_and_send(uint32_t start_address, uint32_t length) {
//     uint8_t buffer[64];  // Temporary buffer to hold data read from flash
//     uint32_t offset = 0;

//     while (offset < length) {
//         // Calculate how many bytes to read in this iteration
//         uint32_t chunk_size = (length - offset >= 64) ? 64 : (length - offset);

//         // Read data from flash memory into the buffer
//         flash_read(buffer, chunk_size, start_address + offset);

//         // Send the read data using kprintf in hexadecimal format
//         kprintf("Data at address 0x%08X: ", start_address + offset);
//         for (uint32_t i = 0; i < chunk_size; ++i) {
//             kprintf("%02X ", buffer[i]);
//         }
//         kprintf("\n");  // Newline after each chunk

//         // Update offset to continue reading the next chunk
//         offset += chunk_size;
//     }

//     kprintf("Flash read complete.\n");
// }





#define FLASH_PAGE_SIZE  0x1000  // Typically 4 KB page size for STM32, adjust if different

// Function to check if flash memory has valid data from Main_APP_START_ADDRESS to Main_APP_START_ADDRESS + file_size
int check_flash_for_valid_data(uint32_t file_size) {
    uint32_t start_address = Main_APP_START_ADDRESS;
    uint32_t end_address = start_address + file_size;

    // Ensure file_size does not exceed flash memory region
    if (end_address > (Main_APP_START_ADDRESS + BOATLOADER_SIZE)) {
        kprintf("File size exceeds available flash memory space.\n");
        return -1;  // Invalid file size
    }

    // Iterate through the flash memory from Main_APP_START_ADDRESS to the end of the file
    for (uint32_t address = start_address; address < end_address; address += 4) {
        uint32_t data = *(volatile uint32_t*)address;  // Read 4 bytes of data

        if (data != 0xFFFFFFFF) {
            kprintf("Found valid data at address: 0x%08X\n", address);
            return 5;  // Found valid data, return 5
        }
    }

    // If no valid data found, return -1
    kprintf("No valid data found in the specified flash range.\n");
    return -1;
}














//  // Adjust include as necessary for your library setup

// #define FLASH_OPTKEY1 0x08192A3B
// #define FLASH_OPTKEY2 0x4C5D6E7F
// #define RDP_LEVEL_0 0xAA
// #define RDP_LEVEL_1 0xFF  // Example value, use a non-0xAA/0xCC value
// #define RDP_LEVEL_2 0xCC

// void unlock_option_bytes() {
//     if (FLASH->OPTCR & FLASH_OPTCR_OPTLOCK) {
//         // Unlock sequence for option bytes
//         FLASH->OPTKEYR = FLASH_OPTKEY1;
//         FLASH->OPTKEYR = FLASH_OPTKEY2;
//     }
// }

// void lock_option_bytes() {
//     FLASH->OPTCR |= FLASH_OPTCR_OPTLOCK;
// }

// int check_flash_ready() {
//     // Check if the BSY flag is cleared (no operation ongoing)
//     while (FLASH->SR & FLASH_SR_BSY);
//     return 1;
// }

// void clear_flash_errors() {
//     // Clear all relevant error flags
//     FLASH->SR |= FLASH_SR_WRPERR | FLASH_SR_PGAERR | FLASH_SR_PGPERR | FLASH_SR_PGSERR;
// }

// int write_flash(uint32_t start_address, const uint8_t *data, size_t length) {
//     // Ensure start_address is 4-byte aligned
//     if (start_address % 4 != 0) return -1;

//     // Unlock flash memory for writing
//     if (FLASH->CR & FLASH_CR_LOCK) {
//         FLASH->KEYR = FLASH_KEY1;
//         FLASH->KEYR = FLASH_KEY2;
//     }

//     // Unlock option bytes if needed for RDP or write protection
//     unlock_option_bytes();

//     // Check for Flash ready status
//     if (!check_flash_ready()) return -1;

//     // Clear any previous errors
//     clear_flash_errors();

//     for (size_t i = 0; i < length; i += 4) {
//         // Create a 32-bit word from the 4 bytes of data
//         uint32_t word = (data[i]) | (data[i+1] << 8) | (data[i+2] << 16) | (data[i+3] << 24);

//         // Ensure Flash is ready
//         if (!check_flash_ready()) return -1;

//         // Enable programming mode
//         FLASH->CR |= FLASH_CR_PG;

//         // Write the 4-byte word to Flash
//         *(uint32_t *)(start_address + i) = word;

//         // Wait until BSY is cleared
//         if (!check_flash_ready()) return -1;

//         // Check for write protection error
//         if (FLASH->SR & FLASH_SR_WRPERR) {
//             clear_flash_errors();
//             return -1; // Write protection error
//         }
        
//         // Disable programming mode
//         FLASH->CR &= ~FLASH_CR_PG;
//     }

//     // Lock Flash memory after writing
//     FLASH->CR |= FLASH_CR_LOCK;
    
//     // Lock option bytes
//     lock_option_bytes();

//     return 0;  // Success
// }








 // Starting address for main application in Flash

// void write_string_to_flash(void) {
//     // The string you want to write to flash
//     const char *s = "abcdefgh";
    
//     // Calculate the length of the string including the null terminator
//     uint32_t length = 9;  // length of string "abcdefgh" + 1 for null terminator

//     // Ensure the string length is a multiple of 4 bytes for flash writing
//     uint32_t padded_length = (length + 3) & ~3;

//     // Create a buffer to store the padded string (with 0xFF)
//     uint8_t buffer[padded_length];
    
//     // Manually set the buffer to 0xFF (erased state for flash memory)
//     for (uint32_t i = 0; i < padded_length; i++) {
//         buffer[i] = 0xFF;
//     }

//     // Manually copy the string into the buffer
//     for (uint32_t i = 0; i < length; i++) {
//         buffer[i] = s[i];
//     }

//     // Call the flash write function with the padded buffer
//     if (f(Main_APP_START_ADDRESS, buffer, padded_length) != 0) {
//         // Handle error (e.g., log or indicate failure)
//         kprintf("error occurs");
//     }
//     else{
//          kprintf("good  occurs");
//     }
// }








void write_string_to_flash(void) {
    // The string you want to write to flash
    const char *s = "fayekziss";
    
    // Get the length of the string including the null terminator
    uint32_t length =8;  // Add 1 for null terminator
    
    
    // Write the string to flash starting from Main_APP_START_ADDRESS
    flash_write((uint8_t*)s, length, Main_APP_START_ADDRESS);
   
}

void write_string_to_flash1(char *s) {
    // The string you want to write to flash
    
    
    // Get the length of the string including the null terminator
    uint32_t length =2;  // Add 1 for null terminator
    
    
    // Write the string to flash starting from Main_APP_START_ADDRESS
    flash_write1((uint8_t*)s, length,0x08010000);
   
}





char  flash_read1(uint32_t length, uint32_t start_address) {
    uint8_t data[length];  // Allocate an array to store the data read from flash
    
    for (uint32_t i = 0; i < length; i++) {
        // Read one byte from flash
        data[i] = *(uint8_t *)(start_address + i);

        // Display the byte in both hexadecimal and character format
        if (data[i] >= 32 && data[i] <= 126) { 
            return data[i];
             // Check if the byte is a printable ASCII character
            kprintf("Data at from flash read  0x%x: 0x%02X ('%c')\n", (start_address + i), data[i], data[i]);
        } else {
            kprintf("Data at from flash read 0x%x: 0x%02X\n", (start_address + i), data[i]);
        }

        // Wait until the flash is not busy
        while (FLASH->SR & FLASH_SR_BSY);
    }

    return 'f';
}






















void kmain(void)
{

    vector_setup();
    __sys_init();
     USART2Config();
    kprintf("Bootloader started\n");
    kprintf("Switching to DUOS24\n");

  








 char ch[36];

  
     // kprintf("i am not alive\n");
    


   

  
     
     kprintf("new version number\n");
   //  kprintf("notun\n");
    
//UART_GetString1(USART2,2,ch);




    // version read


   
  

   
    
     kprintf("have u any updated version\n");
      char du[2];
      du[0]='a';
      du[1]='b';
       // UART_GetString1(USART2,2,ch);
      //  write_string_to_flash1(du);

    
     UART_GetString1(USART2,1,ch);
     //ch[0]='y';
   









     //UART_GetString1(USART2,1,ch);



     if(ch[0]=='y'){
        
 flash_unlock();
  
        kprintf("ok,send this");

    char fs[36];
     UART_GetString1(USART2,5,fs);

        // kprintf("%s",ch);

uint32_t file_size = string_to_int(fs);

 
kprintf("%d", file_size);

 uint8_t buffer[1024]; // Adjust the size as needed

    // Ensure the buffer is large enough to hold the file
   
  
    // Receive the binary data
    //erase_os_memory_in_flash();
    
    USART2ReceiveBinary1(buffer, file_size,Main_APP_START_ADDRESS);
   
    ms_delay(5000);
    kprintf("Binary file received successfully\n");








        



     }
     else if(ch[0]=='e'){kprintf("erase");
        erase_os_memory_in_flash();
     }
     else if(ch[0]=='t'){
        kprintf("extract\n");
     }
     else if(ch[0]=='w'){kprintf("write in flash");
           char du[3];
      du[0]='2';
      du[1]='2';
      du[2]='\0';
       // UART_GetString1(USART2,2,ch);
        write_string_to_flash1(du);


//         ms_delay(3000);
//           char re[2];
//    re[0]= flash_read1(1,0x08010000);
//    re[1]=flash_read1(1,0x08010001);
//    kprintf("the reading is : %s",re);
   ms_delay(2000);







     } 
     else if(ch[0]=='a'){
        
        
        kprintf("welcome to automatic\n");


     
        char du[3];
      

          
   du[0]= flash_read1(1,0x08010000);
   du[1]=flash_read1(1,0x08010001);
du[2]='\0';
   int oldversion=string_to_int(du);


    kprintf("old  %s in int is %d\n",du,oldversion+44);


    kprintf("wait for new version\n");
    ms_delay(3000);
    
    kprintf("extract\n");

     char recver[3];
     UART_GetString1(USART2,2,recver);
     recver[2]='\0';
     int newversion=string_to_int(recver);

     kprintf("new version is: %d and old version is: %d\n",newversion,oldversion);

    if(newversion>oldversion){


        kprintf("so prepare for receiving the new os\n");

   
       // UART_GetString1(USART2,2,ch);
        write_string_to_flash1(recver);


        ms_delay(3000);
         flash_unlock();
  
        kprintf("ok,send this");

    char fs[36];
     UART_GetString1(USART2,5,fs);

        // kprintf("%s",ch);

uint32_t file_size = string_to_int(fs);

 
kprintf("%d", file_size);

 uint8_t buffer[1024]; // Adjust the size as needed

    // Ensure the buffer is large enough to hold the file
   
  
    // Receive the binary data
    //erase_os_memory_in_flash();
    
    USART2ReceiveBinary1(buffer, file_size,Main_APP_START_ADDRESS);
   
    ms_delay(5000);
    kprintf("Binary file received successfully\n");






















    }
    else{
        kprintf("no need to update\n");
    }
    




//         ms_delay(3000);
//           char re[2];
//    re[0]= flash_read1(1,0x08010000);
//    re[1]=flash_read1(1,0x08010001);
//    kprintf("the reading is : %s",re);
   ms_delay(2000);







     }
     else if(ch[0]=='n'){
        kprintf("OK ,GOOD BYE\n");

           ms_delay(3000);
         char re[3];
   re[0]= flash_read1(1,0x08010000);
   re[1]=flash_read1(1,0x08010001);
   re[2]='\0';
   kprintf("the reading is : %s\n",re);
   ms_delay(2000);

        //kprintf("notun\n");
      //erase_os_memory_in_flash();
        // char du[5];
        // UART_GetString1(USART2,2,du);
        // write_string_to_flash1(du);

//      char notun[2];
//    notun[0]= flash_read1(1,0x08010000);
//    notun[1]=flash_read1(1,0x08010001);
//    int version=string_to_int(notun);

//    if(version<10){
//     kprintf("version is less than %d\n",version+20);

//    }
//    if(version>30){
//     kprintf("version is less than %d\n",version+30);
//    }

//     kprintf("notun is %s\n",notun);

        //
      //  kprintf("data in flash %d :\n",check_flash_for_valid_data(3));
          //kprintf("flash checked: %d", flash_erased_check());
     }







    //*VERSION_ADDR = 47; 
     kprintf("wait for 5 seconds\n");
    



       // Size of the binary file written to flash

    // Call the function to read from flash and send data
    //flash_read_and_send(Main_APP_START_ADDRESS, file_sizes);







   
    ms_delay(5000);
   
    
    jump_to_main();


    kprintf("This should not print if jump is successful\n");
}

// Bootloader   Main frame 
// Bootloader   64 kiB  64-34=30KiB  30KiB padding 
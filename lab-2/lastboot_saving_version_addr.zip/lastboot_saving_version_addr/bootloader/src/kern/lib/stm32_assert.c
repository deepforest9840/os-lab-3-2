#include <stm32_assert.h>
void assert_failed(uint8_t *file, uint32_t line)
{
 //kprintf("Assert failed: file %s on line %d\r\n", file, line);

}